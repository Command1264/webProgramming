package com.github.command1264.webProgramming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebProgrammingApplicationTests {

	@Test
	void contextLoads() {
	}

}
