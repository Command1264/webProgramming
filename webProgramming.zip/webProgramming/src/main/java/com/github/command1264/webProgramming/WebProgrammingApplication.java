package com.github.command1264.webProgramming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebProgrammingApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebProgrammingApplication.class, args);
	}

}
